/**
 * @Author tangdekun
 * @Date 2018/7/30-14:31
 * @Email tangdekun0924@gmail.com
 */
class AppDataManager : DataManager {
}