package com.tdk.daggerdemo.second.ui

import com.tdk.daggerdemo.AppComponent
import com.tdk.daggerdemo.CustomScopeName
import com.tdk.daggerdemo.second.ui.second.SecondViewModel
import dagger.Component

/**
 * @Author tangdekun
 * @Date 2018/7/30-16:35
 * @Email tangdekun0924@gmail.com
 */
@CustomScopeName
@Component(modules = [SecondFragmentModule::class], dependencies = [AppComponent::class])
interface SecondFragmentComponent {
    fun inject(mSecondViewModel: SecondViewModel)
}