package com.tdk.daggerdemo

/**
 * @Author tangdekun
 * @Date 2018/7/30-15:02
 * @Email tangdekun0924@gmail.com
 */
object AppComponentHolder {
    lateinit var mAppComponent: AppComponent
}