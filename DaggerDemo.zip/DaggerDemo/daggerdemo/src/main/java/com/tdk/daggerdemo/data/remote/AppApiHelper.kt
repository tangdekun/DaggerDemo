/**
 * @Author tangdekun
 * @Date 2018/7/30-14:29
 * @Email tangdekun0924@gmail.com
 */
class AppApiHelper : ApiHelper {
}