package com.tdk.daggerdemo.second.ui

import com.tdk.daggerdemo.second.ui.second.SecondViewModel
import dagger.Module

/**
 * @Author tangdekun
 * @Date 2018/7/30-16:34
 * @Email tangdekun0924@gmail.com
 */
@Module
class SecondFragmentModule(mSecondViewModel: SecondViewModel) {
}