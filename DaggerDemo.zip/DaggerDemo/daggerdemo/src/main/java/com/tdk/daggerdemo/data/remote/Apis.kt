/**
 * @Author tangdekun
 * @Date 2018/7/30-14:25
 * @Email tangdekun0924@gmail.com
 */
interface Apis {


}